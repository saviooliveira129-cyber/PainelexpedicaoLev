-- PAINEL OPERACIONAL · EXPEDIÇÃO — banco (Supabase)
-- 1) Troque TROQUE_ESTA_SENHA (linha marcada abaixo) pela senha dos editores.
-- 2) Cole tudo no SQL Editor do Supabase e clique em Run.

create extension if not exists pgcrypto with schema extensions;

create table if not exists cds (id text primary key, name text not null, sub text not null, pos int default 0);
create table if not exists days (
  cd text not null, date date not null,
  rows jsonb not null default '[]', src jsonb not null default '{}',
  cut jsonb not null default '{}', col jsonb not null default '{}', prod jsonb not null default '{}',
  upd timestamptz, edt timestamptz, file text default '', primary key (cd, date));
create table if not exists history (
  cd text not null, date date not null,
  dia numeric default 0, emb numeric default 0, sep numeric default 0, falta numeric default 0,
  preso numeric default 0, ped numeric default 0, vol numeric default 0, pend numeric default 0,
  man boolean default false, edt timestamptz, primary key (cd, date));
create table if not exists config (id int primary key default 1 check (id = 1), pw text not null);

-- Segurança: todos LEEM; ninguém grava direto. A gravação só acontece pelas funções abaixo, que exigem a senha.
alter table cds enable row level security;
alter table days enable row level security;
alter table history enable row level security;
alter table config enable row level security;
drop policy if exists "leitura cds" on cds;
drop policy if exists "leitura days" on days;
drop policy if exists "leitura history" on history;
create policy "leitura cds" on cds for select to anon, authenticated using (true);
create policy "leitura days" on days for select to anon, authenticated using (true);
create policy "leitura history" on history for select to anon, authenticated using (true);

-- >>> TROQUE A SENHA AQUI <<<
insert into config (id, pw) values (1, extensions.crypt('TROQUE_ESTA_SENHA', extensions.gen_salt('bf')))
on conflict (id) do nothing;

create or replace function check_pw(p text) returns boolean language sql security definer
set search_path = public, extensions as $$
  select exists (select 1 from config where pw = crypt(p, pw) and pw <> crypt('TROQUE_ESTA_SENHA', pw))
$$;

create or replace function save_day(p text, d jsonb, h jsonb) returns void language plpgsql security definer
set search_path = public, extensions as $$
begin
  if not check_pw(p) then raise exception 'senha incorreta'; end if;
  insert into days (cd, date, rows, src, cut, col, prod, upd, edt, file)
  values (d->>'cd', (d->>'date')::date, d->'rows', d->'src', d->'cut', d->'col', d->'prod',
          nullif(d->>'upd','')::timestamptz, nullif(d->>'edt','')::timestamptz, coalesce(d->>'file',''))
  on conflict (cd, date) do update set rows=excluded.rows, src=excluded.src, cut=excluded.cut, col=excluded.col,
          prod=excluded.prod, upd=excluded.upd, edt=excluded.edt, file=excluded.file;
  insert into history (cd, date, dia, emb, sep, falta, preso, ped, vol, pend, edt)
  values (h->>'cd', (h->>'date')::date, (h->>'dia')::numeric, (h->>'emb')::numeric, (h->>'sep')::numeric,
          (h->>'falta')::numeric, (h->>'preso')::numeric, (h->>'ped')::numeric, (h->>'vol')::numeric,
          (h->>'pend')::numeric, nullif(h->>'edt','')::timestamptz)
  on conflict (cd, date) do update set dia=excluded.dia, emb=case when history.man then history.emb else excluded.emb end, sep=excluded.sep, falta=excluded.falta,
          preso=excluded.preso, ped=excluded.ped, vol=excluded.vol, pend=excluded.pend, edt=excluded.edt;
end $$;

create or replace function save_hist(p text, h jsonb) returns void language plpgsql security definer
set search_path = public, extensions as $$
begin
  if not check_pw(p) then raise exception 'senha incorreta'; end if;
  insert into history (cd, date, dia, emb, sep, falta, preso, ped, vol, pend, man, edt)
  values (h->>'cd', (h->>'date')::date, coalesce((h->>'dia')::numeric,0), (h->>'emb')::numeric, coalesce((h->>'sep')::numeric,0),
          coalesce((h->>'falta')::numeric,0), coalesce((h->>'preso')::numeric,0), coalesce((h->>'ped')::numeric,0),
          coalesce((h->>'vol')::numeric,0), coalesce((h->>'pend')::numeric,0), true, nullif(h->>'edt','')::timestamptz)
  on conflict (cd, date) do update set emb=excluded.emb, man=true, edt=excluded.edt;
end $$;

create or replace function del_hist(p text, c text, d date) returns void language plpgsql security definer
set search_path = public, extensions as $$
begin
  if not check_pw(p) then raise exception 'senha incorreta'; end if;
  delete from history where cd = c and date = d;
end $$;

create or replace function save_cd(p text, c jsonb) returns void language plpgsql security definer
set search_path = public, extensions as $$
begin
  if not check_pw(p) then raise exception 'senha incorreta'; end if;
  insert into cds (id, name, sub, pos) values (c->>'id', c->>'name', c->>'sub', coalesce((c->>'pos')::int, 0))
  on conflict (id) do update set name = excluded.name, sub = excluded.sub;
end $$;

create or replace function set_pw(p text, np text) returns void language plpgsql security definer
set search_path = public, extensions as $$
begin
  if not check_pw(p) then raise exception 'senha incorreta'; end if;
  update config set pw = crypt(np, gen_salt('bf')) where id = 1;
end $$;

-- Atualização em tempo real
alter publication supabase_realtime add table cds, days, history;

-- Dados iniciais
insert into cds (id, name, sub, pos) values
  ('cd-vila-velha','CD Vila Velha','L021 · LA21',1),
  ('cd-conde','CD Conde','L019',2)
on conflict (id) do nothing;

insert into days (cd, date, rows, src, cut, col, prod, upd, edt, file) values
 ('cd-vila-velha','2026-11-13','[["BRASIL WEB TRANSPORTES E LOGISTICA S/A","L021",0,"L",4,16],["BRASIL WEB TRANSPORTES E LOGISTICA S/A","L021",0,"P",12,60],["BRASIL WEB TRANSPORTES E LOGISTICA S/A","L021",1,"",64,152],["BRASIL WEB TRANSPORTES E LOGISTICA S/A","LA21",0,"L",2,8],["BRASPRESS TRANSPORTES URGENTES LTDA","L021",0,"P",4,8],["BRASPRESS TRANSPORTES URGENTES LTDA","L021",1,"",2,4],["FAVORITA","L021",0,"L",6,12],["FAVORITA","L021",0,"P",43,154],["FAVORITA","L021",1,"",38,101],["FAVORITA","LA21",0,"L",4,24],["FAVORITA","LA21",1,"",2,8],["JAWA TRANSPORTES LTDA","L021",0,"P",34,80],["JAWA TRANSPORTES LTDA","L021",1,"",19,47],["JAWA TRANSPORTES LTDA","LA21",0,"L",3,7],["JAWA TRANSPORTES LTDA","LA21",0,"P",3,20],["JAWA TRANSPORTES LTDA","LA21",1,"",1,36],["RODONAVES AGRO","L021",0,"L",10,30],["RODONAVES AGRO","L021",0,"P",55,267],["RODONAVES AGRO","L021",1,"",237,673],["RODONAVES AGRO","LA21",0,"L",14,52],["RODONAVES AGRO","LA21",0,"P",1,5],["RODONAVES AGRO","LA21",1,"",13,63],["TRANSPORTADORA M.M.A LTDA","L021",0,"L",8,28],["TRANSPORTADORA M.M.A LTDA","L021",0,"P",43,175],["TRANSPORTADORA M.M.A LTDA","L021",1,"",51,119],["TRANSPORTADORA M.M.A LTDA","LA21",0,"L",3,11],["TRANSPORTADORA M.M.A LTDA","LA21",0,"P",2,29],["TRANSPORTADORA M.M.A LTDA","LA21",1,"",16,67]]'::jsonb,
  '{"1":2075,"2":18,"3":97,"4":66}'::jsonb,
  '{"cont":0,"c1":2075,"c2":18,"c3":97,"c4":66,"pend":0}'::jsonb,
  '{"L021":10,"LA21":5}'::jsonb, '{"L021":50,"LA21":35}'::jsonb,
  '2026-11-13T03:09:00Z','2026-11-13T03:35:09Z','painel_operacional_o__painein_.xlsx')
on conflict (cd, date) do nothing;

insert into history (cd, date, dia, emb, sep, falta, preso, ped, vol, pend, edt) values
 ('cd-vila-velha','2026-11-13',2256,0,1270,986,798,694,2256,0,'2026-11-13T03:35:09Z')
on conflict (cd, date) do nothing;
